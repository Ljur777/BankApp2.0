package com.example.bankapp.entity.enums;

public enum CurrencyCode {
    USD,
    UAH,
    EUR
}
