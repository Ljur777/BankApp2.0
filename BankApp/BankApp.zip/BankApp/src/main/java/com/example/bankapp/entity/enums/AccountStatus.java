package com.example.bankapp.entity.enums;

public enum AccountStatus {
    BLOCKED,
    ACTIVE,
    IS_ARCHIVED

}
