package com.example.bankapp.service;

public interface ClientService {
}
