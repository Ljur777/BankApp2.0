package com.example.bankapp.service.Impl;

import com.example.bankapp.dto.ClientDTO;
import com.example.bankapp.entity.Client;
import com.example.bankapp.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ClientServiceImpl implements UserDetailsService {
    @Autowired
    private ClientRepository clientRepository;
 //   @Autowired                                      // Получаем шифровальщика паролей
//    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        return clientRepository.findByName(userName);
    }
  public List<Client> getAll(){
        return clientRepository.findAll();
  }
  public boolean save(Client client){
       // client.setPassword(passwordEncoder.encode(client.getPassword()));
        clientRepository.save(client);
        return true;
  }


    public List<ClientDTO> getAllActiveStatusClients(String status) {
        if(clientRepository.findAll().contains(status))
        return clientRepository.findAll();
    }

    public List<ClientDTO> getAllClientsWhereBalanceMoreThan(BigDecimal balance) {
    }
}
