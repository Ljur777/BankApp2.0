package com.example.bankapp.entity.enums;

public enum ClientStatus {
    ACTIVE,
    BLOCKED,
    ARCHIVED
}
