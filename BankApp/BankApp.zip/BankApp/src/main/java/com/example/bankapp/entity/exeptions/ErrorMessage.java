package com.example.bankapp.entity.exeptions;

public class ErrorMessage {
    public static final String ACCOUNTS_NOT_FOUND = "Any accounts were not founded";
    public static final String ACCOUNT_NOT_FOUND_BY_STATUS = "Account with this status is not found";
}
