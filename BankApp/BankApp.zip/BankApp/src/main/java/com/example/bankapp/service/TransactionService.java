package com.example.bankapp.service;

public interface TransactionService {
}
