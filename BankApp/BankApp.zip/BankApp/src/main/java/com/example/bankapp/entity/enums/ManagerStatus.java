package com.example.bankapp.entity.enums;

public enum ManagerStatus {
    Senior,
    Middle,
    JUNIOR
}
