package com.example.bankapp.dto;

public class ClientCreateDTO {
}
